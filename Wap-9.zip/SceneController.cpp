#pragma once
#include "stdafx.h"
#include "SceneController.h"
#include "logo.h"
#include "menu.h"


SceneNum sceneNum =LOGO;

void EnterNextScene(SceneNum num) 
{
		system("cls"); // �ܼ�ȭ���� ���� �����ش�.
		sceneNum =num; // SceneNum�� �޾ƿͼ�
		Scene_Init(); //Scene�� �ʱ�ȭ�Ѵ�.
}
void Scene_Init()
{
	switch(sceneNum)
	{
	case LOGO:
		Logo_Init();
		break;
	case MENU:
		Menu_Init();
		break;
	case STAGE:
		break;
	default:
		break;
	}
}

void Scene_Update()
{
   switch(sceneNum)
	{
	case LOGO:
		Logo_Update();
		break;
	case MENU:
		Menu_Update();
		break;
	case STAGE:
		break;
	default:
		break;
	}
}
void Scene_Render()
{
	switch(sceneNum)
	{
	case LOGO:
		Logo_Render();
		break;
	case MENU:
		Menu_Render();
		break;
	case STAGE:
		break;
	default:
		break;
	}
}
void Scene_Destroy()
{
	switch(sceneNum)
	{
	case LOGO:
		Logo_Destroy();
		break;
	case MENU:
		Menu_Destroy();
		break;
	case STAGE:
		break;
	default:
		break;
	}
}