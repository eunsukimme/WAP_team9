#include "stdafx.h"
#include "option.h"



void Option_Init()
{
	printf("option_Init");
}
void Option_Update()
{}
void Option_Render()
{}
void Option_Destroy()
{}