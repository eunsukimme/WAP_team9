#pragma once
#include "stdafx.h"
#include "KeyController.h"
#include "MainGame.h"
#include "SceneController.h"

// main�Լ� �� �ּ� Ȯ��
void Logo_Init();
void Logo_Update();
void Logo_Render();
void Logo_Destroy();

